#  Assignment 3

Version: 

- `Python 3.7.9` 

After adding file `books.txt` to the folder

Run the command from terminal:

````
python query.py ["path to txt file containing query urls"]
````